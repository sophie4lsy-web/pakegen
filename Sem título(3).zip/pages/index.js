import Link from 'next/link';
export default function Home() {
  const categories = [
    {key:'beaute', label:'Beauté'},
    {key:'alimentaire', label:'Alimentaire'},
    {key:'hightech', label:'High-Tech'},
    {key:'maison', label:'Maison'},
    {key:'sante', label:'Santé'},
    {key:'mode', label:'Mode'},
    {key:'animalerie', label:'Animalerie'}
  ];
  return (
    <div style={{padding:40, fontFamily:'Arial, sans-serif', background:'#fff'}}>
      <h1 style={{marginBottom:6}}>Pakegen</h1>
      <p style={{color:'#555'}}>Choisissez une catégorie pour commencer</p>
      <div style={{display:'flex', gap:12, flexWrap:'wrap', marginTop:20}}>
        {categories.map(c=>(
          <Link key={c.key} href={`/templates?category=${c.key}`} legacyBehavior>
            <a style={{textDecoration:'none'}}><button style={{padding:12, minWidth:140, cursor:'pointer', background:'#fff', border:'1px solid #e6e6e6', borderRadius:6}}>{c.label}</button></a>
          </Link>
        ))}
      </div>
    </div>
  );
}
