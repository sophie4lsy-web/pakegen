import path from 'path';
import Database from 'better-sqlite3';

const DB_PATH = path.join(process.cwd(), 'database', 'packify.db');

export default function handler(req, res) {
  try {
    const db = new Database(DB_PATH, { readonly: true });
    const { category } = req.query;
    let rows;
    if (category) {
      rows = db.prepare('SELECT id, category, name, preview, pdf FROM templates WHERE category = ? LIMIT 200').all(category);
    } else {
      rows = db.prepare('SELECT id, category, name, preview, pdf FROM templates LIMIT 200').all();
    }
    db.close();
    return res.status(200).json({ templates: rows });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'DB error' });
  }
}
