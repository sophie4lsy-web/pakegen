import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';
import TemplateCard from '../components/TemplateCard';

export default function Templates() {
  const router = useRouter();
  const { category } = router.query;
  const [templates, setTemplates] = useState([]);

  useEffect(() => {
    if (!category) return;
    fetch(`/api/templates?category=${category}`)
      .then(r=>r.json())
      .then(data=>setTemplates(data.templates || []))
      .catch(()=>setTemplates([]));
  }, [category]);

  return (
    <div style={{padding:30, fontFamily:'Arial, sans-serif', background:'#fff'}}>
      <h2 style={{marginBottom:6}}>Templates — {category}</h2>
      <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(220px,1fr))', gap:16, marginTop:12}}>
        {templates.map(t=> <TemplateCard key={t.id} template={t} />)}
      </div>
    </div>
  );
}
