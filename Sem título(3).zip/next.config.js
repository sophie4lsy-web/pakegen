/** @type {import('next').NextConfig} */
module.exports = {
  reactStrictMode: true,
  env: {
    PACKIFY_SEED_RUN: "1"
  }
}
