# Pakegen (Packify Studio)

Ce projet est prêt à être uploadé sur GitHub et déployé sur Vercel.

## Déploiement rapide (sans terminal)
1. Crée un repository GitHub (ex: `pakegen`).
2. Téléversez **l'intégralité** du contenu de ce ZIP via "Add file → Upload files".
3. Créez un compte Vercel et connectez votre compte GitHub.
4. Dans Vercel, cliquez "New Project" → importez le repo `pakegen` → Deploy.

## Remarques
- Le script `scripts/seed.js` génère des templates de démonstration (PDF + PNG).
- Par défaut la génération est réglée sur 10 templates par catégorie pour limiter la taille.
- Pour augmenter le nombre de templates, modifiez `count` dans `scripts/seed.js`.
