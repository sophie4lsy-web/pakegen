const fs = require('fs');
const path = require('path');
const PDFDocument = require('pdfkit');
const { createCanvas } = require('canvas');
const Database = require('better-sqlite3');

const OUT_PUBLIC = path.join(__dirname, '..', 'public', 'templates');
const DB_FILE = path.join(__dirname, '..', 'database', 'packify.db');

const categories = [
  { key: 'beaute', label: 'Beauté' },
  { key: 'alimentaire', label: 'Alimentaire' },
  { key: 'hightech', label: 'High-Tech' },
  { key: 'maison', label: 'Maison' },
  { key: 'sante', label: 'Santé' },
  { key: 'mode', label: 'Mode' },
  { key: 'animalerie', label: 'Animalerie' }
];

if (!fs.existsSync(OUT_PUBLIC)) fs.mkdirSync(OUT_PUBLIC, { recursive: true });
if (!fs.existsSync(path.dirname(DB_FILE))) fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });

const db = new Database(DB_FILE);
db.exec(`CREATE TABLE IF NOT EXISTS templates (id INTEGER PRIMARY KEY, category TEXT, name TEXT, preview TEXT, pdf TEXT);`);

const insert = db.prepare('INSERT INTO templates (category, name, preview, pdf) VALUES (@category,@name,@preview,@pdf)');
const count = 10; // demo count per category

for (const cat of categories) {
  const dirCat = path.join(OUT_PUBLIC, cat.key);
  if (!fs.existsSync(dirCat)) fs.mkdirSync(dirCat, { recursive: true });

  for (let i = 1; i <= count; i++) {
    const id = `${cat.key}_${i}`;
    const pdfPath = `/templates/${cat.key}/${id}.pdf`;
    const pngPath = `/templates/${cat.key}/${id}.png`;
    const absPdf = path.join(OUT_PUBLIC, cat.key, `${id}.pdf`);
    const absPng = path.join(OUT_PUBLIC, cat.key, `${id}.png`);

    // PDF
    const doc = new PDFDocument({ size: 'A4', margin: 0 });
    const stream = fs.createWriteStream(absPdf);
    doc.pipe(stream);
    doc.fontSize(20).text(`${cat.label} - Template ${i}`, 100, 100);
    // draw simple bleed rect
    doc.rect(10,10,595-20,842-20).lineWidth(0.5).stroke('#cccccc');
    doc.end();

    // PNG preview (simple)
    const canvas = createCanvas(600, 400);
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#fff';
    ctx.fillRect(0,0,600,400);
    ctx.fillStyle = '#222';
    ctx.font = '20px sans-serif';
    ctx.fillText(`${cat.label} - Template ${i}`, 40, 60);
    fs.writeFileSync(absPng, canvas.toBuffer('image/png'));

    insert.run({ category: cat.key, name: `${cat.label} Template ${i}`, preview: pngPath, pdf: pdfPath });
  }
}

db.close();
console.log('Templates generated');
