import { useRouter } from 'next/router';
export default function TemplateCard({ template }) {
  const router = useRouter();
  const choose = () => router.push(`/form?templateId=${template.id}`);
  return (
    <div style={{border:'1px solid #eee', borderRadius:8, padding:12, background:'#fff'}}>
      <img src={template.preview} alt="" style={{width:'100%', height:140, objectFit:'cover', borderRadius:4}} />
      <h4 style={{margin:'8px 0'}}>{template.name}</h4>
      <div style={{display:'flex', gap:8}}>
        <button onClick={choose} style={{flex:1}}>Choisir ce template</button>
        <a href={template.pdf} target="_blank" rel="noreferrer"><button>Télécharger PDF</button></a>
      </div>
    </div>
  );
}
